package it.uniud.ducktypesystem.distributed.messages;

import java.io.Serializable;

public class DSMove implements Serializable {
}
